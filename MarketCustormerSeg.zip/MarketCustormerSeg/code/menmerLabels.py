import numpy as np
import pandas as pd

rmf = pd.read_csv("../data/rmf.csv")
df = pd.read_csv("../data/cumcm2018_join.csv") #会员

#会员年龄计算
from datetime import datetime as dt
# print(df.info())
now_year =dt.today().year #当前的年份

df["csrq"]=pd.to_datetime(df["csrq"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
df['age']=now_year-df["csrq"].dt.year
df.loc[:,'age'].fillna(df['age'].mean(), inplace=True)   #会员年龄为空的填充其均值
df['age'] = df['age'].astype("int")

df["age_level"]=pd.cut(df["age"],bins=[0,18,65,79,100],
                                   labels=["未成年","青年","中年","老年"])
df["xb"]=df["xb"].replace({0:"男",1:"女"})
df["dtime"]=pd.to_datetime(df["dtime"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
df.loc[:,"dtm"]=df["dtime"].dt.hour
df["time_level"]=pd.cut(df["dtm"],bins=[0,6,12,18,24],labels=["凌晨","早上","下午","晚上"])

#将统计出来的会员消费记录信息与会员聚类分析结果连接得出会员的标签库cum_res.csv
res=pd.merge(rmf,df)

# print(res.columns)#I['kh', 'F_scory', 'M_score', 'R_score', 'cluster.label', 'M_level',
       # 'F_level', 'csrq', 'xb', 'djsj', 'dtime', 'spbm', 'sl', 'sj', 'je',
       # 'spmc', 'jf', 'syjh', 'djh', 'gzbm', 'gzmc', 'age', 'age_level', 'dtm',
       # 'time_level']
res=res[['kh','cluster.label','M_level','F_level','R_score','xb','age_level','time_level']]
res.drop_duplicates(subset="kh").reset_index(drop=True)
res.to_csv("../data/memberLabels.csv",encoding="utf-8",index=0)



