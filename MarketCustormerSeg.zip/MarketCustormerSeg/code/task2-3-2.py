import numpy as np
import pandas as pd

df = pd.read_csv("../data/cumcm2018_join.csv")
df["dtime"]=pd.to_datetime(df["dtime"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
df.loc[:,"dtm"]=df["dtime"].dt.hour
df=df.set_index('dtime')  #将dtime作为df的索引

Q_je=df["je"].resample('Q').sum().to_period('Q')   #按季度
Q_index=[]
for i in Q_je.index:
    Q_index.append(i)

#绘图
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(10,6))
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False

x=np.arange(len(list(Q_je.index)))
y=list(Q_je.values)
xticks=Q_index
plt.bar(x,y,align='center',color = 'c',alpha=0.8)
plt.plot(y,color='r')

plt.xticks(x,xticks)
plt.xlabel('各年份各季度')
plt.ylabel('消费金额（元)')
plt.title('各年份各季度会员消费金额走势图',)
for a,b in zip(x,y):
   plt.text(a, b+0.05, '%.0f' % b, ha='center', va= 'bottom',fontsize=8)
# plt.savefig("../result/task2-3-2")
plt.show()