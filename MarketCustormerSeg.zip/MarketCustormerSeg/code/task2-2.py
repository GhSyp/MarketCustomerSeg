import numpy as np
import pandas as pd
df = pd.read_csv("../data/cumcm2018_join.csv") #会员
cumcm2018c2 = pd.read_csv("../data/cumcm2018c2.csv")
cumcm2018c2_null=cumcm2018c2[cumcm2018c2["kh"].isnull()]  #非会员

cumcm_djh=list(df[["djh"]].count())  #会员消费订单数
no_cumcm_djh=list(cumcm2018c2_null[["djh"]].count()) #非会员消费订单数
cumcm_djh.extend(no_cumcm_djh) #[会员订单数，非会员订单数]

cumcm_je=list(df[["je"]].sum()) #会员消费金额总数
no_cumcm_je=list(cumcm2018c2_null[["je"]].sum())#非会员消费总数
cumcm_je.extend(no_cumcm_je)

df["dtime"]=pd.to_datetime(df["dtime"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
df=df.set_index('dtime')  #将dtime作为df的索引
Ytime=[i.strftime("%Y")for i in df.index]
df["Ytime"]=Ytime  #取年

#按年统计消费金额
Y_je=df[["je","Ytime"]].groupby(by="Ytime").agg(np.sum)


#绘图
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(10,6))
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
#task2-2
fig.add_subplot(1,3,3)
plt.plot(Y_je.index,Y_je.values)
plt.xticks(range(len(Y_je.index)),Y_je.index,rotation=45)
plt.xlabel('年份')
plt.ylabel('消费金额（元)')
plt.title('3.各年份会员消费金额金额走势图',)

x=np.arange(2)+1 #设置x轴柱子的个数
xticks=["会员","非会员"] #构造不同年龄类目的数列
y=cumcm_djh#设置y轴的数值，需将je列的数据先转化为数列，再转化为矩阵格式
fig.add_subplot(1,3,1)
plt.bar(x,y,align='center',color = 'c',alpha=0.8)
plt.xticks(x,xticks)#设置x轴的刻度，将构建的xticks代入，设置字体和对齐方式size='small',rotation=30
plt.ylabel('订单总数')
plt.title("1.会员与非会员订单总数")
for a,b in zip(x,y):
  plt.text(a, b+0.05, '%.0f' % b, ha='center', va= 'bottom',fontsize=7)


x=np.arange(2)+1 #设置x轴柱子的个数
xticks=["会员","非会员"] #构造不同年龄类目的数列
y=cumcm_je#设置y轴的数值，需将je列的数据先转化为数列，再转化为矩阵格式
fig.add_subplot(1,3,2)
plt.bar(x,y,align='center',color = 'g',alpha=0.8)
plt.xticks(x,xticks)#设置x轴的刻度，将构建的xticks代入，设置字体和对齐方式size='small',rotation=30
plt.ylabel('消费金额(元)')
plt.title("2.会员与非会员消费金额情况",)
for a,b in zip(x,y):
  plt.text(a, b+0.05, '%.0f' % b, ha='center', va= 'bottom',fontsize=8)
# plt.savefig("../result/task2-2")
plt.show()