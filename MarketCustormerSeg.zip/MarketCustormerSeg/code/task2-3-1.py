import numpy as np
import pandas as pd
df = pd.read_csv("../data/cumcm2018_join.csv")
df["dtime"]=pd.to_datetime(df["dtime"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
df.loc[:,"dtm"]=df["dtime"].dt.hour
df=df.set_index('dtime')  #将dtime作为df的索引

df["time_level"]=pd.cut(df["dtm"],bins=[0,6,12,18,24],labels=["凌晨","早上","下午","晚上"])
#各时间段会员消费人数
time_pie=df[["kh","time_level"]].groupby(by="time_level").count()

#绘图
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(10,6))
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False

labels=["凌晨","早上","下午","晚上"]
plt.pie(time_pie.values,labels=labels,autopct='%1.1f%%',shadow=False,startangle=150)
plt.title("会员消费时段占比图")
plt.axis('equal')
# plt.savefig("../result/task2-3-1")
plt.show()