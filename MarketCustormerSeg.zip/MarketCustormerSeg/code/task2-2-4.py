import numpy as np
import pandas as pd
df = pd.read_csv("../data/cumcm2018_join.csv") #会员

df["dtime"]=pd.to_datetime(df["dtime"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
df=df.set_index('dtime')  #将dtime作为df的索引
Mtime=[i.strftime("%Y-%m")for i in df.index]
df["Mtime"]=Mtime  #取月

M_je=df[["je","Mtime"]].groupby(by="Mtime").agg(np.sum)   #按月

#绘图
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(10,6))
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False

plt.plot(M_je.index,M_je.values)
plt.xticks(rotation=45)
plt.xlabel('月份')
plt.ylabel('消费金额（元)')
plt.title('4.各年份各月份会员消费金额走势图')
plt.savefig("../result/task2-2-4")

plt.show()