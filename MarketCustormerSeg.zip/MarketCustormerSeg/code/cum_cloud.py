#选取某一位会员进行画像的构建
import wordcloud
import pandas as pd
from imageio import imread      #导入imageio绘图
data = pd.read_csv('../data/cum_res.csv')

data = data[data.kh=="000186fa"]

count = data.groupby(by=["kh","time_level"])["age_level"].count()
time_count = count.reset_index()
dic = {x[1]:x[2] for x in time_count.values}

data = data.drop(columns=["kh","time_level"])
for i in range(len(data.columns)):
  count_all = data.iloc[:,i].value_counts()
  count_all = count_all.reset_index()
  for x in count_all.values:
      dic[x[0]]=x[1]

mask_of_by = imread('../data/back.jpg')   # 图片轮廓
wc = wordcloud.WordCloud(mask=mask_of_by,width=100,
    height=150,font_path="simhei.ttf",background_color="white",max_words=40,colormap="coolwarm")
X=wc.generate_from_frequencies(dic)
X.to_file("../result/task3-4.png")
