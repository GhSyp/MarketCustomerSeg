import numpy as np
import pandas as pd

cumcm2018c1 = pd.read_excel("../data/cumcm2018c1.xlsx",parse_dates=['csrq'])
cumcm2018c2 = pd.read_csv("../data/cumcm2018c2.csv")
rmf = pd.read_csv("../data/rmf.csv")
cumcm2018_join = pd.merge(cumcm2018c1,cumcm2018c2,how="outer")

# print(cumcm2018c1.columns) #['kh', 'csrq', 'xb', 'djsj']
#会员与非会员
# print("原数据集大小：",cumcm2018c2.shape)

#会员信息表卡号去重
# print("原数据集大小：",cumcm2018c1.shape)
# print("卡号重复记录数：",cumcm2018c1["kh"].duplicated())
cumcm2018c1_dp=cumcm2018c1.drop_duplicates(subset="kh").reset_index(drop=True)
# print("去重后的数据集大小：",cumcm2018c1_dp.shape)
cumcm2018c2_null=cumcm2018c2[cumcm2018c2["kh"].isnull()]
# print("卡号存在空值的数据集大小（非会员）：",cumcm2018c2_null.shape)
cumcm2018c2_nonull=cumcm2018c2.dropna(subset=["kh"])
cumcm2018c2_nonull=cumcm2018c2_nonull.loc[cumcm2018c2_nonull['kh'].isin(cumcm2018c1_dp['kh']),:]
# print("去除空值后的数据集大小（会员）：",cumcm2018c2_nonull.shape)
# print("会员消费记录：",cumcm2018c2_nonull)
# print("非会员消费记录：",cumcm2018c2_null)


cumcm_djh=list(cumcm2018c2_nonull[["djh"]].count())  #会员消费订单数
no_cumcm_djh=list(cumcm2018c2_null[["djh"]].count()) #非会员消费订单数
cumcm_djh.extend(no_cumcm_djh)


cumcm_je=list(cumcm2018c2_nonull[["je"]].sum()) #会员消费金额总数
no_cumcm_je=list(cumcm2018c2_null[["je"]].sum())#非会员消费总数
cumcm_je.extend(no_cumcm_je)


#会员年龄计算
from datetime import datetime as dt
# print(cumcm2018c1_dp.info())
now_year =dt.today().year #当前的年份
cumcm2018c1_dp["csrq"]=pd.to_datetime(cumcm2018c1_dp["csrq"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
cumcm2018c1_dp['age']=now_year-cumcm2018c1_dp["csrq"].dt.year
cumcm2018c1_dp.loc[:,'age'].fillna(cumcm2018c1_dp['age'].mean(), inplace=True)
cumcm2018c1_dp['age'] = cumcm2018c1_dp['age'].astype("int")
# print(cumcm2018c1_dp.head())
cumcm2018c1_dp["age_level"]=pd.cut(cumcm2018c1_dp["age"],bins=[0,65,79,100],
                                   labels=["青年","中年","老年"])
cumcm2018c1_dp["xb"]=cumcm2018c1_dp["xb"].replace({0:"男",1:"女"})

age_pie=cumcm2018c1_dp["age_level"].value_counts()   #会员各年龄段人数
agg=cumcm2018c1_dp["xb"].value_counts()   #会员性别统计
# age_agg=cumcm2018c1_dp["age"].value_counts()
# age_agg = age_agg.sort_index()#给统计后的数据排序

#会员信息表与销售流水表连接--》会员的基本信息、消费记录
cumcm2018_join = pd.merge(cumcm2018c1_dp,cumcm2018c2_nonull,how="outer")
cumcm2018_join["dtime"]=pd.to_datetime(cumcm2018_join["dtime"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
df=cumcm2018_join[pd.notnull(cumcm2018_join["dtime"])&(cumcm2018_join.je>0)]     #筛选消费日期不为空值和消费金额小于零的记录

df.loc[:,"dtm"]=df["dtime"].dt.hour
df["time_level"]=pd.cut(df["dtm"],bins=[0,6,12,18,24],labels=["凌晨","早上","下午","晚上"])

#将统计出来的会员消费记录信息与会员聚类分析结果连接
res=pd.merge(rmf,df)
# print(res.columns)#Index(['kh', 'F_scory', 'M_score', 'R_score', 'cluster.label', 'M_level',
       # 'F_level', 'csrq', 'xb', 'djsj', 'age', 'age_level', 'dtime', 'spbm',
       # 'sl', 'sj', 'je', 'spmc', 'jf', 'syjh', 'djh', 'gzbm', 'gzmc', 'dtm',
       # 'time_level'],
res=res[['kh','cluster.label',"M_score",'M_level','F_level','R_score','xb','age_level','time_level']]
res.drop_duplicates(subset="kh").reset_index(drop=True)
res.to_csv("../data/cum_res.csv",encoding="utf-8",index=0)

df["xfje_level"]=pd.cut(res["M_score"],bins=[0,res["M_score"].mean()*0.5,res["M_score"].mean(),res["M_score"].mean()*2],
                       labels=["低消费","中消费","高消费"])

#各时间段会员消费人数
time_pie=df[["kh","time_level"]].groupby(by="time_level").count()


df=df.set_index('dtime')  #将dtime作为df的索引
df=df["1900-01-01":"2018-12-31"]
Ytime=[i.strftime("%Y")for i in df.index]
Mtime=[i.strftime("%Y-%m")for i in df.index]
df["Ytime"]=Ytime  #取年
df["Mtime"]=Mtime  #取月

#统计各特征下的消费金额
age_je=cumcm2018_join[["je","age_level"]].groupby(by="age_level").agg(np.sum)  #按年龄
xb_je=cumcm2018_join[["je","xb"]].groupby(by="xb").agg(np.sum)  #按性别
Y_je=df[["je","Ytime"]].groupby(by="Ytime").agg(np.sum)  #按年
M_je=df[["je","Mtime"]].groupby(by="Mtime").agg(np.sum)   #按月
Q_je=df["je"].resample('Q').sum().to_period('Q')   #按季度
Q_index=[]
for i in Q_je.index:
    Q_index.append(i)

#绘图
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(10,6))
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False

'''
#task2-3-1
labels=["凌晨","早上","下午","晚上"]
plt.pie(time_pie.values,labels=labels,autopct='%1.1f%%',shadow=False,startangle=150)
plt.title("会员消费时段占比图")
plt.axis('equal')
plt.savefig("../result/task2-3-1")
'''


#task2-3-2
x=np.arange(len(list(Q_je.index)))
y=list(Q_je.values)
xticks=Q_index
plt.bar(x,y,align='center',color = 'c',alpha=0.8)
plt.plot(y,color='r')

plt.xticks(x,xticks)
plt.xlabel('各年份各季度')
plt.ylabel('消费金额（元)')
plt.title('各年份各季度会员消费金额走势图',)
for a,b in zip(x,y):
   plt.text(a, b+0.05, '%.0f' % b, ha='center', va= 'bottom',fontsize=8)
plt.savefig("../result/task2-3-2")


'''
#task2-2
fig.add_subplot(1,3,3)
plt.plot(Y_je.index,Y_je.values)
plt.xticks(range(len(Y_je.index)),Y_je.index,rotation=45)
plt.xlabel('年份')
plt.ylabel('消费金额（元)')
plt.title('3.各年份会员消费金额金额走势图',)

x=np.arange(2)+1 #设置x轴柱子的个数
xticks=["会员","非会员"] #构造不同年龄类目的数列
y=cumcm_djh#设置y轴的数值，需将je列的数据先转化为数列，再转化为矩阵格式
fig.add_subplot(1,3,1)
plt.bar(x,y,align='center',color = 'c',alpha=0.8)
plt.xticks(x,xticks)#设置x轴的刻度，将构建的xticks代入，设置字体和对齐方式size='small',rotation=30
plt.ylabel('订单总数')
plt.title("1.会员与非会员订单总数")
for a,b in zip(x,y):
  plt.text(a, b+0.05, '%.0f' % b, ha='center', va= 'bottom',fontsize=7)


x=np.arange(2)+1 #设置x轴柱子的个数
xticks=["会员","非会员"] #构造不同年龄类目的数列
y=cumcm_je#设置y轴的数值，需将je列的数据先转化为数列，再转化为矩阵格式
fig.add_subplot(1,3,2)
plt.bar(x,y,align='center',color = 'g',alpha=0.8)
plt.xticks(x,xticks)#设置x轴的刻度，将构建的xticks代入，设置字体和对齐方式size='small',rotation=30
plt.ylabel('消费金额(元)')
plt.title("2.会员与非会员消费金额情况",)
for a,b in zip(x,y):
  plt.text(a, b+0.05, '%.0f' % b, ha='center', va= 'bottom',fontsize=8)
plt.savefig("../result/task2-2")
'''

'''
#task2-2-4
plt.plot(M_je.index,M_je.values)
plt.xticks(rotation=45)
plt.xlabel('月份')
plt.ylabel('消费金额（元)')
plt.title('4.各年份各月份会员消费金额金额走势图')
plt.savefig("../result/task2-2-4")
'''

'''
#task1
x=np.arange(len(age_je.index))+1 #设置x轴柱子的个数
xticks=list(age_je.index) #构造不同年龄类目的数列
y=np.array(list(age_je['je']))#设置y轴的数值，需将je列的数据先转化为数列，再转化为矩阵格式
fig.add_subplot(2,2,1)
plt.bar(x,y,width = 0.35,align='center',color = 'c',alpha=0.8)
plt.xticks(x,xticks)#设置x轴的刻度，将构建的xticks代入，设置字体和对齐方式size='small',rotation=30
plt.ylabel('消费金额(元)')
plt.title("会员不同年龄段消费金额情况")
for a,b in zip(x,y):
  plt.text(a, b+0.05, '%.0f' % b, ha='center', va= 'bottom',fontsize=7)


fig.add_subplot(2,2,2)
plt.pie(age_pie.values,labels=age_pie.index,autopct='%1.1f%%',shadow=False,startangle=150)
plt.title("会员年龄占比图")
plt.axis('equal')


labels = ['女','男']
fig.add_subplot(2,2,3)
plt.pie(agg.values,labels=labels,autopct='%1.1f%%',shadow=False,startangle=150)
plt.title("会员男女比例图")
plt.axis('equal')

fig.add_subplot(2,2,4)
plt.pie(xb_je.values,labels=["男","女"],autopct='%1.1f%%',shadow=False,startangle=150)

plt.title("不同性别会员消费金额占比图")
plt.axis('equal')
plt.savefig('../result/task2-1.jpg')
plt.show()
'''







