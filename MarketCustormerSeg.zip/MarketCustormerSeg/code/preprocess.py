import numpy as np
import pandas as pd

cumcm2018c1 = pd.read_excel("../data/cumcm2018c1.xlsx",parse_dates=['csrq'])
cumcm2018c2 = pd.read_csv("../data/cumcm2018c2.csv")

#会员与非会员
# print("原数据集大小：",cumcm2018c2.shape)
#会员信息表卡号去重
# print("原数据集大小：",cumcm2018c1.shape)
# print("卡号重复记录数：",cumcm2018c1["kh"].duplicated())
cumcm2018c1_dp=cumcm2018c1.drop_duplicates(subset="kh").reset_index(drop=True)
# print("去重后的数据集大小：",cumcm2018c1_dp.shape)
cumcm2018c2_null=cumcm2018c2[cumcm2018c2["kh"].isnull()] #非会员
# print("卡号存在空值的数据集大小（非会员）：",cumcm2018c2_null.shape)
cumcm2018c2_nonull=cumcm2018c2.dropna(subset=["kh"])  #会员
#筛选出本商场的会员的购物信息
cumcm2018c2_nonull=cumcm2018c2_nonull.loc[cumcm2018c2_nonull['kh'].isin(cumcm2018c1_dp['kh']),:]
# print("去除空值后的数据集大小（会员）：",cumcm2018c2_nonull.shape)
# print("会员消费记录：",cumcm2018c2_nonull)
# print("非会员消费记录：",cumcm2018c2_null)


#会员信息表与销售流水表连接--》会员的基本信息、消费记录
cumcm2018_join = pd.merge(cumcm2018c1_dp,cumcm2018c2_nonull,how="outer")
cumcm2018_join["dtime"]=pd.to_datetime(cumcm2018_join["dtime"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
# 筛选消费日期不为空值和消费金额小于零的记录(小于0可能为退货)
df=cumcm2018_join[pd.notnull(cumcm2018_join["dtime"])&(cumcm2018_join.je>0)]
df.to_csv("../data/cumcm2018_join.csv",encoding="utf-8",index=0)


#数据探索
ep=cumcm2018_join.describe(include="all").T
dt_not_null=cumcm2018_join[(cumcm2018_join["kh"].notnull())&(cumcm2018_join["je"].notnull())]
# print(dt_not_null.columns)
# print(dt_not_null.describe().T)