import numpy as np
import pandas as pd
df = pd.read_csv("../data/cumcm2018_join.csv") #会员

#会员年龄计算
from datetime import datetime as dt
# print(df.info())
now_year =dt.today().year #当前的年份
df["csrq"]=pd.to_datetime(df["csrq"],errors='coerce')#If ‘coerce’, then invalid parsing will be set as NaT.
df['age']=now_year-df["csrq"].dt.year
df.loc[:,'age'].fillna(df['age'].mean(), inplace=True)   #会员年龄为空的填充其均值
df['age'] = df['age'].astype("int")


df["age_level"]=pd.cut(df["age"],bins=[0,18,65,79,100],
                                   labels=["未成年","青年","中年","老年"])
df["xb"]=df["xb"].replace({0:"男",1:"女"})
age_pie=df["age_level"].value_counts()   #会员各年龄段人数
print(age_pie)
agg=df["xb"].value_counts()   #会员性别统计

age_je=df[["je","age_level"]].groupby(by="age_level").agg(np.sum)  #按年龄
xb_je=df[["je","xb"]].groupby(by="xb").agg(np.sum)  #按性别


#绘图
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(10,6))
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False

x=np.arange(len(age_je.index))+1 #设置x轴柱子的个数
xticks=list(age_je.index) #构造不同年龄类目的数列
y=np.array(list(age_je['je']))#设置y轴的数值，需将je列的数据先转化为数列，再转化为矩阵格式
fig.add_subplot(2,2,1)
plt.bar(x,y,width = 0.35,align='center',color = 'c',alpha=0.8)
plt.xticks(x,xticks)#设置x轴的刻度，将构建的xticks代入，设置字体和对齐方式size='small',rotation=30
plt.ylabel('消费金额(元)')
plt.title("会员不同年龄段消费金额情况")
for a,b in zip(x,y):
  plt.text(a, b+0.05, '%.0f' % b, ha='center', va= 'bottom',fontsize=7)


fig.add_subplot(2,2,2)
colors = ['green', 'yellow', 'blue', '#ff9999']
#决定分割部分，及其与其它部分之间的间距
expl = [0.1,0,0,0]
plt.pie(age_pie.values,labels=age_pie.index,autopct='%1.1f%%',wedgeprops={'linewidth':1.5,'edgecolor':'red'},pctdistance = 0.6, startangle =180,shadow=False,explode=expl,colors=colors)
plt.title("会员年龄占比图")
plt.axis('equal')


labels = ['女','男']
fig.add_subplot(2,2,3)
plt.pie(agg.values,labels=labels,autopct='%1.1f%%',shadow=False,startangle=150)
plt.title("会员男女比例图")
plt.axis('equal')

fig.add_subplot(2,2,4)
plt.pie(xb_je.values,labels=["男","女"],autopct='%1.1f%%',shadow=False,startangle=150)

plt.title("不同性别会员消费金额占比图")
plt.axis('equal')
plt.savefig('../result/task2-1.jpg')
# plt.show()