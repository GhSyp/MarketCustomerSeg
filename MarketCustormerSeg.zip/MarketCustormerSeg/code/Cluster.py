import pandas as pd
import numpy as np
from datetime import datetime as dt

datafile = pd.read_csv("../data/cumcm2018_join.csv") #会员
#数据透视表
rfm = datafile.pivot_table(
       index = 'kh',
       values = ['csrq','djsj','dtime','je','djh'],
       aggfunc = {

                   'dtime':'max', # 最近消费时间
                   'je':'mean',
                   'djh':'count',
                   })

rfm['endtime'] = 20171231  #假设观测时间窗口
rfm.endtime = pd.to_datetime(rfm.endtime,format = '%Y%m%d')
# 添加一个 R_score字段
rfm['R_score']= pd.DataFrame(pd.to_datetime(rfm.endtime) - pd.to_datetime(rfm.dtime))
# 把日期days 转换为以int类型的天数
rfm['R_score']= rfm['R_score'].dt.days.astype(int)

 # 需要的字段重新命名，不需要的进行drop丢弃处理
rfm = rfm.rename(columns={'je':'M_score','djh':'F_scory'})
rfm = rfm.drop(columns=['dtime', 'endtime'])
rfm2=rfm.reset_index('kh')

import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
data = StandardScaler().fit_transform(rfm)
# print('标准化后的三个特征为：\n',data[:5])

# 构建模型
#1、用户分组数K值的选择
SSE = [] # 存放每次结果的误差平方和
for k in range(2,7):
    kmeans_model = KMeans(n_clusters = k ,n_jobs = 4,random_state = 123)
    fit_kmeans = kmeans_model.fit(data)
    SSE.append(kmeans_model.inertia_)
X = range(2, 7)
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
fig = plt.figure(figsize=(10, 6))
fig.add_subplot(221)
plt.xlabel('k',fontsize=12)
plt.ylabel('SSE',fontsize=12)
plt.title("客户细分簇数k与模型误差平方和SSE分析图",fontsize=14)
plt.plot(X, SSE, 'o-')

# #print(fit_kmeans.predict([[18, 660.038889,97]]))
#根据客户细分簇数k与模型误差平方和SSE分析图得出选用 k=4最佳
kmeans_model = KMeans(n_clusters = 4 ,n_jobs = 4,random_state = 123)
fit_kmeans = kmeans_model.fit(data)
label = pd.DataFrame(kmeans_model.labels_)
label.columns = ['cluster.label']
res = pd.concat([rfm2,label], axis = 1)
# print(res)#kh  F_scory       M_score  R_score  cluster.label

r1 = pd.Series(kmeans_model.labels_).value_counts() #统计各个类别的数目
r2 = pd.DataFrame(kmeans_model.cluster_centers_) #找出聚类中心
# 所有簇中心坐标值中最大值和最小值
max = r2.values.max()
min = r2.values.min()
r = pd.concat([r2, r1], axis = 1) #横向连接（0是纵向），得到聚类中心对应的类别下的数目
r.columns = list(rfm.columns) + [u'类别数目'] #重命名表头

ax = fig.add_subplot(122,polar=True)
center_num = r.values
feature = ["消费次数", "消费金额", "消费时间", ]
N = len(feature)
for i, v in enumerate(center_num):
    # 设置雷达图的角度，用于平分切开一个圆面
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False)
    # 为了使雷达图一圈封闭起来，需要下面的步骤
    center = np.concatenate((v[:-1], [v[0]]))
    angles = np.concatenate((angles, [angles[0]]))
    # 绘制折线图
    ax.plot(angles, center, 'o-', linewidth=2, label="第%d簇人群,%d人" % (i + 1, v[-1]))
    # 填充颜色
    ax.fill(angles, center, alpha=0.25)
    # 添加每个特征的标签
    ax.set_thetagrids(angles * 180 / np.pi, feature, fontsize=11)
    # 设置雷达图的范围
    ax.set_ylim(min - 0.1, max + 0.1)
    # 添加标题
    plt.title('客户群特征分析图', fontsize=16)
    # 添加网格线
    ax.grid(True)
    # 设置图例
    plt.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0), ncol=1, fancybox=True, shadow=True)

# 显示图形
# plt.savefig("./result/task4-2")
plt.show()

import seaborn as sns
# 密度图
'''
figg=plt.figure(figsize=(16, 10), dpi=80)
plt.title("各簇用户的RFM特征值概率密度函数图",fontsize=14)
feature=[ 'R_score','F_scory', 'M_score']
for i in range(4):
    for j in range(3):
        figg.add_subplot(4,3,i*3+(j+1))
        sns.kdeplot(res.loc[res['cluster.label'] == i, feature[j]], shade=True, color="g", label="label="+str(i), alpha=.7)
plt.legend()
plt.savefig("./result/task4-3")
'''

#单特征
res["M_level"]=pd.cut(res["M_score"],bins=[0,res["M_score"].mean()*0.5,res["M_score"].mean(),res["M_score"].mean()*2],
                       labels=["低消费","中消费","高消费"])
res["F_level"]=pd.cut(res["F_scory"],bins=[0,2,5,res["F_scory"].mean(),res["F_scory"].max()],
                    labels=['新会员','老会员','成熟会员','忠实会员'])
res["R_score"]=pd.cut(res["R_score"],bins=[0,90,180,360,res["R_score"].max()],
                    labels=['活跃会员','沉默会员','睡眠会员','流失会员'])
#根据雷达图分析结果及业务知识将聚类结果标识
res['cluster.label']=res['cluster.label'].replace({0:"重要保持客户",1:"重要发展客户",2:"重要挽留客户",3:"一般客户"})
# res.to_csv("../data/rmf.csv",encoding="utf-8",index=0)
